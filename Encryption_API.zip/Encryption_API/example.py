from cryptography.fernet import Fernet

def encrypt(pw):
    key = Fernet.generate_key()
    f = Fernet(key)

    encrypted = f.encrypt(pw.encode())

    print("Key:", key.decode())
    print("Encrypted:", encrypted.decode())

encrypt("Hello")